/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapecalculator;

/**
 *
 * @author DELL
 */
public class Rectangle extends ShapeCalculator 
        
{
    
    
    private double length;
    private double width;

    
    
    
    
    
    public Rectangle(String name, String color, double length, double width) 
    {
        
        super(name, color);
        
        
        this.length = length;
        this.width = width;
        
        
        
    }

    
    
    
    
    
    
    
    
    public double area() 
    {
        return length * width;
    }

    
    
    
    
    public double perimeter() 
    {
        return 2 * (length + width);
    }

    
    
    
    
    

    @Override 

    public void display() 
    {
        
       
        super.display() ;
        
        
        System.out.println("Length     : " + length);
        System.out.println("Width      : " + width);
        System.out.println("Area       : " + area());
        System.out.println("Perimeter  : " + perimeter());
    
        
    } 



    
    
}
