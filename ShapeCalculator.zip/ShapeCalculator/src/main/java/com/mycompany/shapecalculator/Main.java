/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapecalculator;



import java.util.ArrayList;

import java.util.Scanner;



/**
 *
 * @author DELL
 */
public class Main 
{
    
    
     public static void main(String[] args)
     
    {

        Scanner input = new Scanner(System.in);
        
        
        ArrayList<ShapeCalculator> b = new ArrayList<>();

        
        
        
        System.out.println("Enter Circle Info - ") ;
        
     
        
        System.out.print("Name : ") ;
        String name = input.nextLine() ;

        
        
        
        System.out.print("Color : ") ;
        String color = input.nextLine() ;

        
        
        
        
        System.out.print("Radius : ") ;
        double radius = input.nextDouble() ;
        input.nextLine() ;

        
        
        
        
        b.add(new Circle(name, color, radius)) ;

        
        
        
        
        
        System.out.println("\nEnter Rectangle Info - ") ;

        
        
        System.out.print("Name : ") ;
        name = input.nextLine() ;

        System.out.print("Color : ") ;
        color = input.nextLine() ;

        System.out.print("Length : ") ;
        double length = input.nextDouble() ;

        System.out.print("Width : ") ;
        double width = input.nextDouble() ;

        b.add(new Rectangle(name, color, length, width)) ;

        
        
        
        
        System.out.println("\n\n") ; 
        
        
        
        
        
        for (ShapeCalculator s : b) 
        {
            s.display() ;   
        }

        
        
        
        input.close() ;
        
    }
    
}
