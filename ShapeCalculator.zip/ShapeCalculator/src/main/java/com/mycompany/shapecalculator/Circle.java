/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shapecalculator;

/**
 *
 * @author DELL
 */
public class Circle extends ShapeCalculator 
{
    
    
    
    private  double radius ; 

    
    
    
    
    
    
    
    public double getRadius() {
        return radius;
    }

    public void setRadious(double radius) {
        this.radius = radius;
    }
    
    
    
    
    
    public Circle(String name, String color, double radius)
    {
        super(name, color);
 
        this.radius = radius;
    }
    
    
    
    
    
    // Calculate Area
    
    public double area() 
    {
        
        return Math.PI * radius * radius ;
        
    } 




    
    // Calculate Perimeter
    
    public double perimeter() 
    {
        return 2 * Math.PI * radius ;
    }
    
    
    
    
    
    
    
    @Override
    
    public void display() 
    {
     
        
        super.display() ; 
        
        
        
        System.out.println ("Radius : " + radius )   ;
        System.out.printf ("Area   : %.2f%n", area());
        System.out.printf("Perimeter : %.2f%n" , perimeter() ) ; 
        
        
        
        
    
    }   
    
    
}
