public class Main
{

    public static void main (String[] args )
    {

        Cars a = new Cars ("Toyota Corolla", 2022 , 4 ) ;


        Motorcycle b = new Motorcycle ("Yamaha R15", 2023 , "Petrol" ) ;


        Truck c = new Truck ("Volvo FH", 2024 , 20 )  ;



        a.display() ;
        a.start_Engine()  ;
        a.safety_check() ;






        b.display() ;
        b.start_Engine() ;







        c.display() ;
        c.start_Engine() ;
        c.safety_check() ;



    }





}
