public class Truck extends vehicles implements Engine_interface , Safety_interface
{

    private int ton ;


    public int getTon() {
        return ton;
    }

    public void setTon(int ton) {
        this.ton = ton;
    }






    public Truck (String model , int year , int ton)
    {
        super( model ,  year ) ;


        this.ton = ton  ;


    }





    @Override
    public void start_Engine ()
    {
        System.out.println("Engine is OK. ") ;

    }




    @Override
    public void safety_check ()
    {
        System.out.println("Truck all most safe zone. ") ;

    }





    @Override
    public void display ()
    {
        super.display() ;


        System.out.println("Ton : " + ton ) ;



    }



}
