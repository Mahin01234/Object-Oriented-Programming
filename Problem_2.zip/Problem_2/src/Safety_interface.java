public interface Safety_interface
{
    void safety_check () ;

}
