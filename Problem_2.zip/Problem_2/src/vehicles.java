abstract public class vehicles
{

    private String model ;
    private int year ;

    protected vehicles() {
    }


    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }






    public vehicles ( String model , int year )
    {
        this.model = model ;
        this.year = year ;

    }





    public void display ()
    {

        System.out.println("The model name is : " + model )  ;
        System.out.println("Year is : " + year ) ;

    }






}
