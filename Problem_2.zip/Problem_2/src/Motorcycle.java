public class Motorcycle extends vehicles implements Engine_interface
{

    private String fuel_type ;


    public String getFuel_type() {
        return fuel_type;
    }

    public void setFuel_type(String fuel_type) {
        this.fuel_type = fuel_type;
    }




    public Motorcycle (String model , int year , String fuel_type)
    {
        super( model ,  year ) ;

        this.fuel_type = fuel_type  ;

    }






    @Override
    public void start_Engine ()
    {


        System.out.println("Fuel is very importance. ") ;


    }






    @Override

    public void display()
    {
        super.display() ;


        System.out.println("Fuel names is : " + fuel_type ) ;



    }




}