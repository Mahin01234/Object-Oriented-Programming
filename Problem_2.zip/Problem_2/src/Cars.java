public class Cars extends vehicles implements Engine_interface, Safety_interface

{


    private int door ;




    public int getDoor() {
        return door;
    }

    public void setDoor(int door) {
        this.door = door;
    }


    public Cars (String model , int year , int door )
    {
        super( model ,  year ) ;

        this.door = door ;


    }




    @Override
    public void start_Engine ()
    {
        System.out.println("Car safety check completed.") ;

    }




    @Override
    public void safety_check ()
    {
        System.out.println("Car safety check completed.") ;

    }





    @Override
    public void display ()
    {
        super.display() ;
        System.out.println("The total door number is : " + door ) ;


    }



    
}
