/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vehicle;

/**
 *
 * @author DELL
 */
public class Vehicle 
{
    
    private String brand , model , color ; 
    private int price ; 

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
    
    
    
    
    public Vehicle (String brand , String model , String color , int price ) 
    {
        
        this.brand = brand ; 
        this.model = model ; 
        this.color = color ; 
        
        this.price = price ; 
        
    }
    
    
    
    
    
    
    public void display() 
    {
        
        System.out.println ("Brand : " + brand ) ; 
        System.out.println ("Model : " + model ) ; 
        System.out.println ("Color : " + color ) ; 
        System.out.println ("Price is : " + price ) ; 
        
        
    }
    
    
}
