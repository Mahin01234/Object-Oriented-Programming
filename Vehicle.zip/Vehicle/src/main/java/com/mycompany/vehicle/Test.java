/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehicle;

import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class Test 
{
    
    
    public static void main (String[] args ) 
    {
        Car c = new Car ("Toyota", "Corolla", "White", 25000, 4) ; 
        
        Motorcycle m = new Motorcycle("Yamaha", "R", "Blue", 5000, 150.5) ;
        
        
        
         ArrayList<Vehicle> vehicles = new ArrayList<>();

        // Add objects to ArrayList
        vehicles.add(c);
        vehicles.add(m);
        
        for (Vehicle vehicle : vehicles) 
        {
            vehicle.display();
            
            
        }

    }
    
}
