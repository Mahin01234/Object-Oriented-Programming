/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehicle;

/**
 *
 * @author DELL
 */
public class Motorcycle extends Vehicle 
        
        
{
    
    private double speed ; 

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }
    
    
    
    
    
    
    public Motorcycle (String brand , String model , String color , int price , double speed ) 
    {
        
        super (brand , model , color , price) ; 
        
        
        this.speed = speed ; 
        
        
    }
    
    
    
    
    
    @Override 
    
    public void display () 
    {
        super.display() ; 
        
        
        
        System.out.println ("Motorcycle speed is : " + speed ) ; 
        
        
        
        
    }
    
}
