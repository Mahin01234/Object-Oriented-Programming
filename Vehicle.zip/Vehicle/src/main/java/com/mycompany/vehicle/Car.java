/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehicle;

/**
 *
 * @author DELL
 */
public class Car extends Vehicle 
        
{
    
    private int door ; 

    public int getDoor() {
        return door;
    }

    public void setDoor(int door) {
        this.door = door;
    }
    
    
    
    
    public Car (String brand , String model , String color , int price , int door) 
    {
        super(brand , model , color , price ) ; 
        
        this.door = door ; 
        
    }
    
    
    
    
    
    @Override
    public void display ()
    {
        
        super.display() ; 
        
        System.out.println ("The car is total door : " + door ) ; 
        
        
        
        
    }
}
