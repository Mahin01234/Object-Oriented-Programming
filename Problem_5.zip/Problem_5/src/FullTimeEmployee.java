public class FullTimeEmployee extends Employee
        implements SalaryCalculator, Workable {

    private double monthlySalary;


    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public FullTimeEmployee(String name, int employeeId,
                            double monthlySalary) {

        super(name, employeeId);
        this.monthlySalary = monthlySalary;
    }

    @Override
    public void showEmployeeType() {
        System.out.println("Employee Type: Full-Time Employee");
    }

    @Override
    public void calculateSalary() {
        System.out.println("Monthly Salary: " + monthlySalary);
    }

    @Override
    public void work() {
        System.out.println(getName() + " works full-time.");
    }
}


