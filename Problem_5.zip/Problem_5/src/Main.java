public class Main {

    public static void main(String[] args) {

        FullTimeEmployee employee1 =
                new FullTimeEmployee(
                        "Mahin",
                        101,
                        50000
                );

        PartTimeEmployee employee2 =
                new PartTimeEmployee(
                        "Rahim",
                        102,
                        500,
                        80
                );

        Contractor employee3 =
                new Contractor(
                        "Karim",
                        103,
                        100000,
                        6
                );


        System.out.println("----- Full-Time Employee -----");

        employee1.showEmployeeType();

        System.out.println("Name: "
                + employee1.getName());

        System.out.println("Employee ID: "
                + employee1.getEmployeeId());

        employee1.calculateSalary();
        employee1.work();


        System.out.println("\n----- Part-Time Employee -----");

        employee2.showEmployeeType();

        System.out.println("Name: "
                + employee2.getName());

        System.out.println("Employee ID: "
                + employee2.getEmployeeId());

        employee2.calculateSalary();
        employee2.work();


        System.out.println("\n----- Contractor -----");

        employee3.showEmployeeType();

        System.out.println("Name: "
                + employee3.getName());

        System.out.println("Employee ID: "
                + employee3.getEmployeeId());

        employee3.calculateSalary();
        employee3.work();
    }
}


