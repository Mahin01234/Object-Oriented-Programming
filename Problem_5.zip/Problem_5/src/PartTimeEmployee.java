public class PartTimeEmployee extends Employee
        implements SalaryCalculator, Workable {

    private double hourlyRate;
    private int hoursWorked;


    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public PartTimeEmployee(String name, int employeeId,
                            double hourlyRate, int hoursWorked) {

        super(name, employeeId);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;
    }

    @Override
    public void showEmployeeType() {
        System.out.println("Employee Type: Part-Time Employee");
    }

    @Override
    public void calculateSalary() {
        double salary = hourlyRate * hoursWorked;

        System.out.println("Total Salary: " + salary);
    }

    @Override
    public void work() {
        System.out.println(getName() + " works part-time.");
    }
}