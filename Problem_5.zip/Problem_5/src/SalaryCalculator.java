public interface SalaryCalculator {

    void calculateSalary();
}


