public class Contractor extends Employee
        implements SalaryCalculator, Workable {

    private double projectFee;
    private int projectDuration;


    public double getProjectFee() {
        return projectFee;
    }

    public void setProjectFee(double projectFee) {
        this.projectFee = projectFee;
    }

    public int getProjectDuration() {
        return projectDuration;
    }

    public void setProjectDuration(int projectDuration) {
        this.projectDuration = projectDuration;
    }

    public Contractor(String name, int employeeId,
                      double projectFee, int projectDuration) {

        super(name, employeeId);
        this.projectFee = projectFee;
        this.projectDuration = projectDuration;
    }

    @Override
    public void showEmployeeType() {
        System.out.println("Employee Type: Contractor");
    }

    @Override
    public void calculateSalary() {
        System.out.println("Project Fee: " + projectFee);
    }

    @Override
    public void work() {
        System.out.println(getName() + " works as a contractor.");
    }
}

