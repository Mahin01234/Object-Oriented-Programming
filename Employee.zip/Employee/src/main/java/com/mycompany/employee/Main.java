/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;


import java.util.ArrayList ; 
/**
 *
 * @author DELL
 */
public class Main 
{
    
    public static void main (String[] args ) 
    {
        
        ArrayList<Employee> E = new ArrayList<>() ; 
        
        
        E.add(new Manager("Alice Johnson", 101, 75000.0, 15000));
        E.add(new Engineer("Bob Smith", 102, 65000.0, 8000));
        E.add(new Manager("Carol Williams", 103, 82000.0, 20000));
        E.add(new Engineer("David Brown", 104, 70000.0, 5000));
        
        
        
        
        
        
        for (Employee a : E ) 
        {
            a.display() ; 
            
            
            
        }
        
        
        
        
    }
    
    
    
    
    
        
   
    
}
