/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author DELL
 */

public class Engineer extends Employee 


{
    
    
    private double projectBonus;  

   

    public double getProjectBonus() {
        return projectBonus;
    }

    public void setProjectBonus(double projectBonus) {
        this.projectBonus = projectBonus;
    }
    
    
    
    
    

    public Engineer(String name, int id, double salary , double projectBonus ) 
    {
        super(name, id, salary);
        this.projectBonus = projectBonus;
    }

    
    
    
    
    
   
    @Override
    public void display()
    
    {
     
        super.display() ;
        
        System.out.println("Project Bonus: " + projectBonus);

        System.out.println("Total Salary: " + (getSalary() + projectBonus));
       
    }
}