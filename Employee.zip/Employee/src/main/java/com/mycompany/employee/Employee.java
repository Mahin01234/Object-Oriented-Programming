/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.employee;

/**
 *
 * @author DELL
 */
public class Employee 
{
    

    private String name  ; 
    
    private int id ; 
    
    private double salary ; 

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Employee(String name, int id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }
    
    
    
    
    
    
    public void display () 
    {
        
        System.out.println ("Name : " + name ) ; 
        System.out.println ("Id : " + id ) ; 
        
        System.out.println ("Salary : " + salary ) ; 
        
        
        
        
    }
    
    
}
