/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author DELL
 */
public class Manager extends Employee 

{
    
    
    
    private double bonus ; 

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public Manager(String name, int id, double salary , double bonus ) {
        super(name, id, salary);
        this.bonus = bonus;
    }

   

    

    
    
    
    
    
    @Override
    public void display () 
    {
        
        System.out.println("Bonus: " + bonus)  ;
        

        System.out.println("Total Salary: " + (  getSalary() + bonus));
        
    }
    
    
}