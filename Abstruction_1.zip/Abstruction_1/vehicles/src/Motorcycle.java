public class Motorcycle extends Vehicle implements  Engine , Transport
{


    private int cc ;


    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }


    public Motorcycle(String model, int year, int cc) {
        super(model, year);
        this.cc = cc;
    }




    public void display ()
    {
        super.display();
        System.out.println("CC : " + cc) ;

    }






    @Override

    public void startEngine ()
    {

        System.out.println("ok") ;

    }







    @Override
    public void transport ()
    {

        System.out.println("M....") ;


    }
}
