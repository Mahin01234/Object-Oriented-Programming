public class CheckingAccount extends BankAccount  implements Deposit, Withdraw


{




    private double transactionFee;





    public double getTransactionFee() {
        return transactionFee;
    }

    public void setTransactionFee(double transactionFee) {
        this.transactionFee = transactionFee;
    }





    public CheckingAccount(String accountNumber, double balance, double transactionFee)
    {

        super(accountNumber, balance);
        this.transactionFee = transactionFee;
    }




    @Override
    public void deposit(double amount)
    {
        balance = balance + amount;
        System.out.println("Deposited : " + amount);
    }









    @Override
    public void display()
    {
        super.display();
        System.out.println("Transaction Fee : " + transactionFee);
    }






    @Override
    public void withdraw(double amount)
    {

        if (amount + transactionFee <= balance)
        {
            balance = balance - amount - transactionFee;
            System.out.println("Withdrawn : " + amount);
            System.out.println("Transaction Fee : " + transactionFee);
        }
        else
        {
            System.out.println("Insufficient balance.");
        }
    }







}