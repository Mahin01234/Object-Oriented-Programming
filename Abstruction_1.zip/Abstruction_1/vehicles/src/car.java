public class car extends Vehicle implements Engine , Transport

{

    private int door ;


    public int getDoor() {
        return door;
    }

    public void setDoor(int door) {
        this.door = door;
    }


    public car(String model, int year, int door) {
        super(model, year);
        this.door = door;
    }





    @Override

    public void display ()

    {
        super.display() ;
        System.out.println("Door : " + door ) ;

    }







    @Override

    public void startEngine ()
    {

        System.out.println ("Cars Engine.") ;

    }





    @Override

    public  void transport ()
    {

        System.out.println("Transport");


    }
}
