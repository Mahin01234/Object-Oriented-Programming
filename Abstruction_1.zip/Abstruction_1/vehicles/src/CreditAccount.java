public class CreditAccount extends BankAccount  implements Deposit, Withdraw


{

    private double creditLimit;


    public double getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(double creditLimit) {
        this.creditLimit = creditLimit;
    }

    public CreditAccount(String accountNumber, double balance, double creditLimit) {

        super(accountNumber, balance);
        this.creditLimit = creditLimit;
    }







    @Override
    public void display()
    {
        super.display();
        System.out.println("Credit Limit : " + creditLimit);
    }







    @Override
    public void deposit(double amount)
    {
        balance = balance + amount;
        System.out.println("Deposited : " + amount);
    }






    @Override
    public void withdraw(double amount)
    {

        if (amount <= balance + creditLimit)
        {
            balance = balance - amount;
            System.out.println("Withdrawn : " + amount);
        }
        else
        {
            System.out.println("Credit limit exceeded.");
        }


    }





    
}