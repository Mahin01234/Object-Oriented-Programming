public class SavingsAccount extends BankAccount  implements Deposit, Withdraw


{

    private double interestRate;


    public double getInterestRate()

    {
        return interestRate;
    }




    public void setInterestRate(double interestRate)

    {
        this.interestRate = interestRate;
    }





    public SavingsAccount(String accountNumber, double balance, double interestRate)

    {

        super(accountNumber, balance);
        this.interestRate = interestRate;
    }







    @Override
    public void display()

    {
        super.display();
        System.out.println("Interest Rate : " + interestRate + "%");
    }








    @Override

    public void deposit(double amount)
    {
        balance = balance + amount;
        System.out.println("Deposited : " + amount);
    }





    @Override

    public void withdraw(double amount)
    {
        if (amount <= balance)
        {
            balance = balance - amount;
            System.out.println("Withdrawn : " + amount);
        }
        else
        {
            System.out.println("Insufficient balance.");
        }



    }



    
}