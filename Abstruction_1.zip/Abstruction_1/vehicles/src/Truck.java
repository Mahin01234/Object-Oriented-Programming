public class Truck extends Vehicle implements  Engine , Transport


{


    private double loadCapacity ;


    public double getLoadCapacity() {
        return loadCapacity;
    }

    public void setLoadCapacity(double loadCapacity) {
        this.loadCapacity = loadCapacity;
    }


    public Truck(String model, int year, double loadCapacity) {
        super(model, year);
        this.loadCapacity = loadCapacity;
    }




    @Override


    public void display ()
    {
        super.display() ;
        System.out.println("Load capacity : " + loadCapacity ) ;


    }






    @Override

    public void startEngine ()
    {
        System.out.println("Truck engine started.");
    }






    @Override

    public void transport ()
    {

        System.out.println("Truck is used for transporting goods.");

    }

}
