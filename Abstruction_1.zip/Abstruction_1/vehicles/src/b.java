import java.util.ArrayList;

public class b



{




    public static void main(String[] args)


    {





        SavingsAccount savings = new SavingsAccount(  "S-101",  50000, 5.0  );

        CheckingAccount checking = new CheckingAccount( "C-102", 40000, 100);

        CreditAccount credit = new CreditAccount(  "CR-103", 20000, 50000  );





        ArrayList<BankAccount> accounts = new ArrayList<>();




        accounts.add(savings);
        accounts.add(checking);
        accounts.add(credit);





        for (BankAccount account : accounts) {

            account.display();

            System.out.println("----------------------");
        }



        savings.deposit(5000);
        savings.withdraw(2000);



        System.out.println("----------------------");




        checking.deposit(3000);
        checking.withdraw(5000);



        System.out.println("----------------------");




        credit.deposit(10000);
        credit.withdraw(25000);




    }
}