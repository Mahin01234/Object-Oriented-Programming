public abstract class BankAccount



{

    protected String accountNumber;
    protected double balance;




    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }







    public void display()
    {
        System.out.println("Account Number : " + accountNumber);
        System.out.println("Balance        : " + balance);
    }




}