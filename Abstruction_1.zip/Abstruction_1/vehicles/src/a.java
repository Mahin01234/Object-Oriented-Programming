

import java.util.ArrayList;





public class a
{


    public static void main(String[] args)

    {


        car c = new car ("Toyota Corolla", 2024, 4);




        Motorcycle motorcycle = new Motorcycle("Yamaha R15", 2023, 155);

        Truck truck = new Truck("Volvo FH", 2022, 20);




        ArrayList<Vehicle> vehicles = new ArrayList<>();

        vehicles.add(c);
        vehicles.add(motorcycle);
        vehicles.add(truck);

        for (Vehicle v : vehicles) {

            v.display();

            ((Engine) v).startEngine();

            ((Transport) v).transport();


        }






    }

}
