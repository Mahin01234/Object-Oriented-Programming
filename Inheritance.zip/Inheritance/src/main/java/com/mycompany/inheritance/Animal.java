
package com.mycompany.inheritance;


public class Animal extends Inheritance 
{
    
    private String quality ; 
    
    
    public Animal (String name , int age , String quality) 
    {
        super (name , age) ; 
        this.quality = quality ; 
    }

    
    
    
    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }
    
    
    
    
    
    
    @Override
    
    public void display() 
    {
        super.display() ; 
        System.out.println("Quality : " +getQuality() ) ;
    }
}
