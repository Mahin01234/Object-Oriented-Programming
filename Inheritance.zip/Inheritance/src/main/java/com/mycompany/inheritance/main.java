
package com.mycompany.inheritance;



import java.util.Scanner;



public class main 
{
    
    public static void main (String[] args) 
    {
        
        
        Scanner input = new Scanner(System.in);

        System.out.print("Enter Name: ");
        String name = input.nextLine();

        System.out.print("Enter Age: ");
        int age = input.nextInt();
        
        input.nextLine(); 

        
        
        System.out.print("Enter Quality: ");
        String quality = input.nextLine();

        // Constructor
        Animal d = new Animal (name, age, quality);
        
        
        
        System.out.println("\nInformation:");
        d.display();

        input.close() ; 
        
        
        
        
    }   
    
}
