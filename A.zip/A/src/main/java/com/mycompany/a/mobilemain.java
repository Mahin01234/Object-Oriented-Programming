/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a;

/**
 *
 * @author DELL
 */
public class mobilemain 
{
    
    public static void main (String[] args ) 
    {
        
        mobile s = new mobile() ; 
        
        
        
        s.setBrand("Samsung"); 
        s.setModel(2024); 
        s.setStorageCapacity(128); 
        System.out.println("Smartphone Information:");
        System.out.println("Brand: " + s.getBrand()  );
        
        
        
        
        System.out.println("Model: " + s.getModel()  ) ;
        
        
        
        
        
        System.out.println("Original Storage: " +  s.getStorageCapacity() + " GB"); 
        s.increaseStorage(128); 
        System.out.println("Storage after increase: " + s.getStorageCapacity() + " GB")   ;  
        
        
        
        
                
    }
    
}
