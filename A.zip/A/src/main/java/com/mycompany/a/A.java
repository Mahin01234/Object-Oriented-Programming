/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.a;

import java.util.Scanner ; 


/**
 *
 * @author DELL
 */
public class A {

    public static void main (String[] args ) 
    {
        
        
        Scanner a = new Scanner (System.in )  ; 
        
        
        System.out.println ("Enter your name : " ) ; 
        String name = a.nextLine() ; 
        
        
        
        
        
        System.out.println ("Enter Gender : " ) ; 
        String gender = a.nextLine() ; 
        
        
        
        
        
        
        System.out.println ("Enter your address : " ) ; 
        String address = a.nextLine() ; 
        
        
        
        
        
        System.out.println ("Enter your age : " ) ; 
        int age = a.nextInt() ; 
        a.nextLine() ; 
        
        
        
        
        
        
        Person b = new Person (name , gender , address , age ) ;
                
                
                
                
        
        
        b.display () ; 
        
        
        
        
        
        
    }
}
