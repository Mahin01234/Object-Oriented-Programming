/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a;

/**
 *
 * @author DELL
 */
public class mmain 
{
    
    public static void main (String[] args ) 
    {
        
        m book = new m() ;
        
        
        book.setTitle("Java") ; 
        book.setAuthor("james") ; 
        book.setPrice(1000.00) ; 
        
        
        
        
        
        
        System.out.println("Title: " + book.getTitle()); 
        System.out.println("Author: " + book.getAuthor()); 
        System.out.println("Original Price: " + book.getPrice());
        
        
        
        
        
        book.applyDiscount(20); 
        
        
        System.out.println("Price after discount: " + book.getPrice());
    }
    
}
