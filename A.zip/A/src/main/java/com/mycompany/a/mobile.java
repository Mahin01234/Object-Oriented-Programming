/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a;

/**
 *
 * @author DELL
 */
public class mobile 
{
    
    
    private String brand ; 
    private int model  , storageCapacity  ; 

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getModel() {
        return model;
    }

    public void setModel(int model) {
        this.model = model;
    }

    public int getStorageCapacity() {
        return storageCapacity;
    }

    public void setStorageCapacity(int storageCapacity) {
        this.storageCapacity = storageCapacity;
    }
    
    
    
    
    
    
    
    
    public mobile (String brand , int model , int storageCapacity ) 
            
    {
        
        this.brand = brand ; 
        
        this.model = model ; 
        
        this.storageCapacity = storageCapacity ; 
        
        
        
        
    } 
    
    
    
    
    
    
    
    
    public void display() 
    {
        
        System.out.println ("Brand : " +  brand ) ;
        System.out.println ("Model : " + model ) ; 
        System.out.println ("storageCapacity : " + storageCapacity )  ; 
        
        
        
        
        
        
        
    }
    
    
    
    public void increaseStorage(int value) 
    { 
        storageCapacity = storageCapacity + value; 
    }
    
    
    
    
    
    
    
    
    
    
    
}
