/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a;

/**
 *
 * @author DELL
 */
public class Person 
{
    
    private String name , gender , address  ;
    private int age ; 

    
    
    
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    
    
    
    
    
    
    public Person (String name , String gender , String address , int age )  
    {
        
        this.name = name ; 
        this.gender = gender ; 
        this.address = address ; 
        this.age = age ; 
    }
    
    
    
    
    
    public void display () 
    {
        System.out.println("Name is : " + name ) ; 
        
        System.out.println("Gender : " + gender ) ; 
        
        System.out.println("Address : " + address ) ; 
        
        System.out.println("Age : " + age ) ; 
        
        
        
    } 
    
    
    
    
    
    
}
