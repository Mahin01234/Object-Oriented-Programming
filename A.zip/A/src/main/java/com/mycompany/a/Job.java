/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a;

/**
 *
 * @author DELL
 */
public class Job 
{
    
    private String name , designation ; 
    
    private int id  ; 
    
    private double salary ; 

    
    
    
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getdesignation () {
        return designation ;
    }

    public void setdesignation (String designation) {
        this.designation = designation ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    
    
    
    
    
    
    
    public Job (String name , String designation , int id , double salary ) 
    {
        
        this.name = name ; 
        
        this.designation = designation ; 
        
        
        this.id = id ; 
        
        
        this.salary = salary ; 
        
        
        
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    public void display() 
    {
        
        System.out.println ("Name : " + name ) ; 
        
        System.out.println ("designation : " + designation ) ; 
         
        System.out.println ("Id is : " + id ) ; 
        
        
        System.out.println ("Salary is : " + salary ) ; 
        
        
        
        
    }
    
    
}
