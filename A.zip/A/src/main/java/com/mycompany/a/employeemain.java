/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.a;

import java.util.Scanner ; 




/**
 *
 * @author DELL
 */
public class employeemain 
{
    
    
    public static void main (String[] args )  
    {
        
        
        Scanner z = new Scanner(System.in ) ; 
        
        
        System.out.println ("Employee name : " ) ; 
        String name = z.nextLine() ; 
        
        
        
        
        
        System.out.println ("Employee designation : " ) ; 
        String designation = z.nextLine() ;
        
        
        
        
        System.out.println ("Employee id is : " ) ; 
        int id = z.nextInt () ;
        
        
        
        
        
        
        
        
        
        System.out.println ("Employee salary : " ) ; 
        double salary = z.nextDouble() ; 
        
        
        
        
        
        
        Job q = new Job (name , designation , id , salary )  ; 
        
        
        
        q.display() ; 
    }
     
}
