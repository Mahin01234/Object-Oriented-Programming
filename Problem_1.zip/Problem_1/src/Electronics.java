public class Electronics extends Product implements Discount_Interface , Warranty_Interface
{

    private int warrantyYears ;




    public int getWarrantyYears() {
            return warrantyYears;
    }


    public void setWarrantyYears(int warrantyYears) {
            this.warrantyYears = warrantyYears;
        }





    public Electronics (String name , int price , int warrantyYears )
    {
         super(name , price ) ;

         this.warrantyYears = warrantyYears ;




    }






    @Override
    public double calculateDiscount() {
        return getPrice() * 0.10  ;
    }




    @Override
    public void warranty() {
        System.out.println("Warranty : " + warrantyYears + " Years");
    }






    @Override

    public void display ()
    {
        super.display() ;

        System.out.println("Discount : " + calculateDiscount()) ;

        warranty();




    }







}
