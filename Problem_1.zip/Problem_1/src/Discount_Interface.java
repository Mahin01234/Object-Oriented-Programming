
public interface Discount_Interface
{
    double calculateDiscount() ;

}






