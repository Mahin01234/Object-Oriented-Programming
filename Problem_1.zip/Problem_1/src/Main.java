
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ArrayList<Product> list = new ArrayList<>();

        list.add(new Electronics("Laptop", 80000, 2));
        list.add(new clothing("T-Shirt", 1200, "L"));
        list.add(new Book("Java Programming", 650, "James Gosling"));

        for (Product p : list) {




            p.display();
            System.out.println("----------------------");
        }
    }
}