public interface Warranty_Interface

{

    void warranty()  ;
}
