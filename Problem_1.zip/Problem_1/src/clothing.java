public class clothing extends Product implements Discount_Interface
{

    private String size ;


    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }






    public clothing(String name, int price, String size)
    {

        super(name, price);
        this.size = size;
    }




    @Override
    public double calculateDiscount() {

        return getPrice() * 0.15;
    }




    @Override
    public void display()

    {

        super.display();
        System.out.println("Size : " + size);
        System.out.println("Discount : " + calculateDiscount());
    }



}
