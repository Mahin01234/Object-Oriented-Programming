public class Main {

    public static void main(String[] args)


    {






        SavingsAccount s = new SavingsAccount("S101", 10000, 5.5);
        CheckingAccount c = new CheckingAccount("C201", 15000, 10);
        CreditAccount cr = new CreditAccount("CR301", 20000, 50000);






        s.deposit(2000);
        s.withdraw(1000);
        s.applyLoan();
        s.display();





        c.deposit(3000);
        c.withdraw(500);
        c.display();






        cr.deposit(4000);
        cr.withdraw(2500);
        cr.applyLoan();
        cr.display();





    }
}