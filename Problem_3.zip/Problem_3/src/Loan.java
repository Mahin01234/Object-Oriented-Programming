public interface Loan
{

    void applyLoan () ;

    
}