public class CreditAccount extends Account implements Transaction, Loan {

    private double creditLimit;


    public double getCreditLimit() {
        return creditLimit;
    }

    public void setCreditLimit(double creditLimit) {
        this.creditLimit = creditLimit;
    }







    public CreditAccount(String accountNumber, double balance, double creditLimit) {
        super(accountNumber, balance);
        this.creditLimit = creditLimit;
    }








    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit: " + amount);
    }







    public void withdraw(double amount) {
        balance -= amount;
        System.out.println("Withdraw: " + amount);
    }






    public void applyLoan() {
        System.out.println("Loan Applied for Credit Account");
    }






    void display() {
        System.out.println("\nCredit Account");
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
        System.out.println("Credit Limit: " + creditLimit);
    }



    
}