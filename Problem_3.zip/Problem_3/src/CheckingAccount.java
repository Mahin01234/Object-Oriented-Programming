public class CheckingAccount extends Account implements Transaction {

    private int transactionLimit;


    public int getTransactionLimit() {
        return transactionLimit;
    }

    public void setTransactionLimit(int transactionLimit) {
        this.transactionLimit = transactionLimit;
    }




    public CheckingAccount(String accountNumber, double balance, int transactionLimit) {
        super(accountNumber, balance);
        this.transactionLimit = transactionLimit;
    }






    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit: " + amount);
    }




    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdraw: " + amount);
        } else {
            System.out.println("Insufficient Balance");
        }
    }





    void display() {
        System.out.println("\nChecking Account");
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
        System.out.println("Transaction Limit: " + transactionLimit);
    }



    
}