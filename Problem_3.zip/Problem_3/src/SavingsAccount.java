public class SavingsAccount extends Account implements Transaction, Loan {

    private double interestRate;




    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }




    public SavingsAccount(String accountNumber, double balance, double interestRate) {
        super(accountNumber, balance);
        this.interestRate = interestRate;
    }





    public void deposit(double amount) {
        balance += amount;
        System.out.println("Deposit: " + amount);
    }





    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdraw: " + amount);
        } else {
            System.out.println("Insufficient Balance");
        }
    }







    public void applyLoan() {
        System.out.println("Loan Applied for Savings Account");
    }







    void display() {
        System.out.println("\nSavings Account");
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
        System.out.println("Interest Rate: " + interestRate + "%");
    }
}