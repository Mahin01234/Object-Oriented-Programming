public class RegularUser extends User implements PostContent



{





    private int age;


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }





    public RegularUser(String username, String profilePicture, int age) {

        super(username, profilePicture);
        this.age = age;
    }





    @Override
    public void display()
    {
        super.display();
        System.out.println("Age : " + age);
    }








    @Override
    public void postContent()
    {
        System.out.println("Regular user posted content.");
    }





}