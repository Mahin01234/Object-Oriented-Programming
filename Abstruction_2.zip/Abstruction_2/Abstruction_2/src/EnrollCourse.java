public interface EnrollCourse
{

    void enrollCourse();




}