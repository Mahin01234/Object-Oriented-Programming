public abstract class Student

{





    protected String name;
    protected int studentId;






    public Student(String name, int studentId)

    {
        this.name = name;
        this.studentId = studentId;
    }






    public void display()
    {
        System.out.println("Name       : " + name);
        System.out.println("Student ID : " + studentId);
    }




    
}