public class Graduate extends Student  implements EnrollCourse, Research
{




    private String thesisTopic;


    public String getThesisTopic() {
        return thesisTopic;
    }

    public void setThesisTopic(String thesisTopic) {
        this.thesisTopic = thesisTopic;
    }





    public Graduate(String name, int studentId, String thesisTopic)
    {

        super(name, studentId);
        this.thesisTopic = thesisTopic;
    }








    @Override
    public void display()
    {
        super.display();
        System.out.println("Thesis Topic : " + thesisTopic);
    }







    @Override
    public void enrollCourse()
    {
        System.out.println("Graduate student enrolled in a course.");
    }






    @Override
    public void doResearch()
    {
        System.out.println("Graduate student is doing research.");
    }






}