public interface Research
{

    void doResearch();

    
}