public class BusinessAccount extends User implements PostContent, BusinessFeature {

    private String businessName;


    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }




    public BusinessAccount(String username, String profilePicture, String businessName)
    {

        super(username, profilePicture);
        this.businessName = businessName;
    }



    @Override
    public void display()
    {
        super.display();
        System.out.println("Business Name   : " + businessName);
    }







    @Override
    public void postContent()
    {
        System.out.println("Business account posted promotional content.");
    }





    
    @Override
    public void businessInfo()
    {
        System.out.println("Business Name   : " + businessName);
    }
}