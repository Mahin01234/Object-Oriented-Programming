public class Undergraduate extends Student implements EnrollCourse


{





    private String major;


    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }






    public Undergraduate(String name, int studentId, String major)
    {

        super(name, studentId);
        this.major = major;
    }








    @Override
    public void display()
    {
        super.display();
        System.out.println("Major      : " + major);
    }










    @Override
    public void enrollCourse()
    {
        System.out.println("Undergraduate student enrolled in a course.");
    }
    




}