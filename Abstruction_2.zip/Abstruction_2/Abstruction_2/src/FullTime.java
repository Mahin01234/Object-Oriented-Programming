public class FullTime extends Employee implements Salary, Bonus


{




    private double monthlySalary;


    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }



    public FullTime(String name, int employeeId, double monthlySalary)
    {

        super(name, employeeId);
        this.monthlySalary = monthlySalary;
    }







    @Override
    public void display()
    {
        super.display();
        System.out.println("Monthly Salary : " + monthlySalary);
    }








    @Override

    public double calculateSalary()
    {
        return monthlySalary;
    }






    @Override

    public double calculateBonus()
    {
        return monthlySalary * 10 / 100;
    }




    
}