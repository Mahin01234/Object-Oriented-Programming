public class Influencer extends User implements PostContent, BusinessFeature {

    private int followers;


    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }

    public Influencer(String username, String profilePicture,  int followers)
    {

        super(username, profilePicture);
        this.followers = followers;
    }









    @Override
    public void display()
    {
        super.display();
        System.out.println("Followers       : " + followers);
    }








    @Override
    public void postContent()

    {
        System.out.println("Influencer posted sponsored content.");
    }





    @Override
    public void businessInfo()
    {
        System.out.println("Influencer can promote products.");
        
    }





}