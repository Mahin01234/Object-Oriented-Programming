public class Contractor extends Employee implements Salary, Bonus


{




    private double contractAmount;


    public double getContractAmount() {
        return contractAmount;
    }

    public void setContractAmount(double contractAmount) {
        this.contractAmount = contractAmount;
    }




    public Contractor(String name, int employeeId, double contractAmount)
    {

        super(name, employeeId);
        this.contractAmount = contractAmount;
    }








    @Override
    public void display()
    {
        super.display();
        System.out.println("Contract Amount : " + contractAmount);
    }







    @Override


    public double calculateSalary()
    {
        return contractAmount;
    }




    @Override
    

    public double calculateBonus()
    {
        return contractAmount * 5 / 100;
    }







}