import java.util.ArrayList;

public class b {




    public static void main(String[] args)


    {




        RegularUser regular = new RegularUser("Mahin", "mahin.jpg", 22);

        BusinessAccount business = new BusinessAccount("TechStore", "techstore.jpg", "Tech Store BD");

        Influencer influencer = new Influencer("Rahim", "rahim.jpg", 50000);




        ArrayList<User> users = new ArrayList<>();




        users.add(regular);
        users.add(business);
        users.add(influencer);





        for (User user : users)

        {

            user.display();

            ((PostContent) user).postContent();


        }
    }
}