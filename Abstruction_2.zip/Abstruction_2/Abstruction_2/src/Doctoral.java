public class Doctoral extends Student implements EnrollCourse, Research


{





    private String researchArea;


    public String getResearchArea() {
        return researchArea;
    }

    public void setResearchArea(String researchArea) {
        this.researchArea = researchArea;
    }






    public Doctoral(String name, int studentId, String researchArea)
    {

        super(name, studentId);
        this.researchArea = researchArea;
    }







    @Override
    public void display()
    {
        super.display();
        System.out.println("Research Area : " + researchArea);
    }







    @Override
    public void enrollCourse()
    {
        System.out.println("Doctoral student enrolled in a course.");
    }








    @Override
    public void doResearch()
    {
        System.out.println("Doctoral student is doing advanced research.");
    }





    
}