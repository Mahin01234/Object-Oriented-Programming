public interface PostContent


{

    void postContent();
}

