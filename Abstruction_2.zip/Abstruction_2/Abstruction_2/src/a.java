import java.util.ArrayList;

public class a


{




    public static void main(String[] args)

    {



        FullTime fullTime = new FullTime(  "Mahin", 101, 50000);

        PartTime partTime = new PartTime( "Rahim",  102, 500, 80   );

        Contractor contractor = new Contractor("Karim", 103, 60000);






        ArrayList<Employee> employees = new ArrayList<>();




        employees.add(fullTime);
        employees.add(partTime);
        employees.add(contractor);




        for (Employee employee : employees)
        {

            employee.display();


        }




        System.out.println("Full-Time Salary : " + fullTime.calculateSalary());

        System.out.println("Full-Time Bonus : " + fullTime.calculateBonus());

        System.out.println("----------------------");

        System.out.println("Part-Time Salary : " + partTime.calculateSalary());

        System.out.println("----------------------");

        System.out.println("Contractor Salary : " + contractor.calculateSalary());

        System.out.println("Contractor Bonus : " + contractor.calculateBonus());








    }
}