public class PartTime extends Employee  implements Salary
{





    private double hourlyRate;
    private int hours;


    public double getHourlyRate() {
        return hourlyRate;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }





    public PartTime(String name, int employeeId,  double hourlyRate, int hours)
    {

        super(name, employeeId);
        this.hourlyRate = hourlyRate;
        this.hours = hours;
    }










    @Override
    public void display()
    {
        super.display();
        System.out.println("Hourly Rate : " + hourlyRate);
        System.out.println("Hours       : " + hours);

    }









    @Override
    public double calculateSalary()
    {
        return hourlyRate * hours;
    }





    
}