public interface BusinessFeature



{

    void businessInfo();
}