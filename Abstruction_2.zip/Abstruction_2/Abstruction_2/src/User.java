public abstract class User


{




    protected String username;
    protected String profilePicture;




    public User(String username, String profilePicture) {
        this.username = username;
        this.profilePicture = profilePicture;
    }





    
    public void display() {
        System.out.println("Username        : " + username);
        System.out.println("Profile Picture : " + profilePicture);
    }
}