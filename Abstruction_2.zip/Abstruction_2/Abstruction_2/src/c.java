import java.util.ArrayList;

public class c



{

    public static void main(String[] args)



    {





        Undergraduate undergraduate = new Undergraduate("Mahin", 101, "Computer Science"   );

        Graduate graduate = new Graduate("Rahim", 102, "Artificial Intelligence"  );




        Doctoral doctoral = new Doctoral("Karim", 103, "Machine Learning");





        ArrayList<Student> students = new ArrayList<>();

        students.add(undergraduate);
        students.add(graduate);
        students.add(doctoral);




        for (Student student : students)
        {

            student.display();

            System.out.println("----------------------");
        }




        undergraduate.enrollCourse();





        System.out.println("----------------------");




        graduate.enrollCourse();
        graduate.doResearch();





        System.out.println("----------------------");




        doctoral.enrollCourse();
        doctoral.doResearch();




    }



}