public class Rectangle extends Shape implements Area, Drawable
{


    private double length;
    private double width;


    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }


    public Rectangle(String color, int x, int y, double length, double width) {
        super(color, x, y);
        this.length = length;
        this.width = width;
    }






    @Override
    public double calculateArea() {
        return length * width;
    }

    @Override
    public void draw() {
        System.out.println("Drawing Rectangle");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Length : " + length);
        System.out.println("Width : " + width);
        System.out.println("Area : " + calculateArea());
    }




    


}
