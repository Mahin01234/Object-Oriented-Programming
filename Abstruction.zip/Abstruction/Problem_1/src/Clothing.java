

public class Clothing extends product implements Discount

{

    private String size ;


    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }


    public Clothing(String name, int price, String size) {
        super(name, price);
        this.size = size;
    }







    @Override
    public int calculateDiscount()

    {
        return getPrice() * 15 ;
    }




    @Override
    public void display()
    {
        super.display();
        System.out.println("Size     : " + size);
        System.out.println("Discount : " + calculateDiscount());
    }







}


