

public class Book extends product implements Discount {

    private String author;


    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Book(String name, int price, String author) {
        super(name, price);
        this.author = author;
    }

    @Override
    public int calculateDiscount() {
        return getPrice() * 5;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Author   : " + author);
        System.out.println("Discount : " + calculateDiscount());
    }
}