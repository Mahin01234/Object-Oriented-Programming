abstract public class product
{

    private String name ;
    private  int price ;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }


    public product(String name, int price) {
        this.name = name;
        this.price = price;
    }





    public void display ()

    {

        System.out.println("Name : " + name ) ;

        System.out.println("Price : " + price ) ;



    }
}
