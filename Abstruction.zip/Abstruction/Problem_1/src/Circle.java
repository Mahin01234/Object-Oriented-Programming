public class Circle extends Shape implements Area, Drawable
{

    private double radius ;


    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public Circle(String color, int x, int y, double radius) {
        super(color, x, y);
        this.radius = radius;
    }



    @Override

    public double calculateArea ()
    {

        return 3.1416 * radius * radius ;

    }




    @Override

    public void draw ()
    {

        System.out.println("Drawing Circle.") ;



    }




    @Override


    public void display ()
    {


        super.display() ;

        System.out.println("Area : " + calculateArea() ) ;


        System.out.println("Radius :  " + radius  ) ;



    }

}
