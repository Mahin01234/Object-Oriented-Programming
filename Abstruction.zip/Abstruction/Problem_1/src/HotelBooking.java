public class HotelBooking extends Booking
{

    private String room_type ;


    public String getRoom_type() {
        return room_type;
    }

    public void setRoom_type(String room_type) {
        this.room_type = room_type;
    }


    public HotelBooking(String b_id, String c_name, int price, String room_type) {
        super(b_id, c_name, price);
        this.room_type = room_type;
    }




    @Override

    public void display()
    {
        super.display();
        System.out.println("Room Type : " + room_type);
    }






    @Override

    public void confirmBooking()
    {
        System.out.println("Hotel confirmed.");
    }







    @Override

    public void cancelBooking()
    {
        System.out.println("Hotel cancelled.");
    }






}
