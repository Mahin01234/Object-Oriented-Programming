

public class Triangle extends Shape implements Area, Drawable {

    private double base;
    private double height;


    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public Triangle(String color, int x, int y,
                    double base, double height) {

        super(color, x, y);

        this.base = base;
        this.height = height;
    }

    @Override
    public double calculateArea() {
        return 0.5 * base * height;
    }

    @Override
    public void draw() {
        System.out.println("Drawing Triangle");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Base : " + base);
        System.out.println("Height : " + height);
        System.out.println("Area : " + calculateArea());
    }
}