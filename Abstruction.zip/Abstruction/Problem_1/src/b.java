

import java.util.ArrayList;

public class b {

    public static void main(String[] args) {

        ArrayList<Shape> shapes = new ArrayList<>();

        Circle c = new Circle("Red", 2, 3, 5);
        Rectangle r = new Rectangle("Blue", 4, 5, 10, 6);
        Triangle t = new Triangle("Green", 1, 2, 8, 4);

        shapes.add(c);
        shapes.add(r);
        shapes.add(t);

        for (Shape s : shapes) {

            s.display();

            ((Drawable) s).draw();


        }
    }
}