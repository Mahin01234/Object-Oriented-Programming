public class Electronics extends product implements Discount, Warranty {

    private int year;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public Electronics(String name, int price, int year) {
        super(name, price);
        this.year = year;
    }

    @Override
    public int calculateDiscount() {
        return getPrice() * 10 / 100;
    }

    @Override
    public void showWarranty() {
        System.out.println("Warranty : " + year + " years");
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Discount : " + calculateDiscount());
        showWarranty();
    }
}