public interface Discount
{

     int calculateDiscount () ;



}
