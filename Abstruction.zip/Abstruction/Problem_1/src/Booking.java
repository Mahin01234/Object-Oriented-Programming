abstract public class Booking
{

    private String b_id ;
    private String c_name ;
    private int price ;


    public String getB_id() {
        return b_id;
    }

    public void setB_id(String b_id) {
        this.b_id = b_id;
    }

    public String getC_name() {
        return c_name;
    }

    public void setC_name(String c_name) {
        this.c_name = c_name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }





    public Booking(String b_id, String c_name, int price) {
        this.b_id = b_id;
        this.c_name = c_name;
        this.price = price;
    }





    public void display ()
    {

        System.out.println("ID : " + b_id ) ;

        System.out.println("Name : " + c_name );

        System.out.println("Price : " + price  ) ;





    }




    public abstract void confirmBooking () ;



    public abstract void cancelBooking () ;



    
}
