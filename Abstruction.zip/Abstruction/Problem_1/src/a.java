
import java.util.ArrayList;




public class a
{



    public static void main(String[] args)
    {

        FlightBooking flight = new FlightBooking ("101" , "Mahin",  15000, "BG-101" )   ;




        HotelBooking hotel = new HotelBooking( "102", "Rahim",  8000,    "Deluxe");






        EventBooking event = new EventBooking(  "103"  , "Karim", 2500, "Music Concert");




        ArrayList<Booking> bookings = new ArrayList<>();


        bookings.add(flight);
        bookings.add(hotel);
        bookings.add(event);

        for (Booking b : bookings) {

            b.display();
            b.confirmBooking();
            b.cancelBooking();

        }




    }



}
