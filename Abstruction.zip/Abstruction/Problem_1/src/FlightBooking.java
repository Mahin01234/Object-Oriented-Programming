public class FlightBooking extends Booking

{

    private  String   FlightBooking  ;


    public String getFlightBooking() {
        return FlightBooking;
    }

    public void setFlightBooking(String flightBooking) {
        FlightBooking = flightBooking;
    }


    public FlightBooking(String b_id, String c_name, int price, String flightBooking) {
        super(b_id, c_name, price);
        FlightBooking = flightBooking;
    }






    @Override
    public void display ()
    {

        super.display();


        System.out.println("Flight Number : " + FlightBooking )  ;



    }











    @Override

    public void confirmBooking ()
    {
        System.out.println("Flight Booking.") ;
    }





    @Override
    public void cancelBooking ()
    {
        System.out.println("Flight Cancelled.");


    }





}
