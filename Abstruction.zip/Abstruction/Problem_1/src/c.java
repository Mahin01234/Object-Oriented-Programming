import java.util.ArrayList;

public class c {

    public static void main(String[] args) {

        Electronics e = new Electronics("Samsung TV", 50000, 2);

        Clothing cf = new Clothing("T-Shirt", 1500, "L");

        Book z = new Book("Java Programming", 1200, "Herbert");

        ArrayList<product> a = new ArrayList<>();

        a.add(e);
        a.add(cf);
        a.add(z);

        for (product p : a) {

            p.display();

            System.out.println("------------------");
        }
    }
}