public class EventBooking extends Booking

{

    private String EeventBooking  ;


    public String getEeventBooking() {
        return EeventBooking;
    }

    public void setEeventBooking(String eeventBooking) {
        EeventBooking = eeventBooking;
    }

    public EventBooking(String b_id, String c_name,
                        int price, String EventBooking) {

        super (b_id , c_name , price  );



        this.EeventBooking = EventBooking   ;


    }







    @Override

    public void display()
    {
        super.display();
        System.out.println("Event Name : " + EeventBooking   );
    }





    @Override

    public void confirmBooking()

    {
        System.out.println("Event confirmed.");
    }







    @Override
    public void cancelBooking() {
        System.out.println("Event cancelled.");
    }






}
