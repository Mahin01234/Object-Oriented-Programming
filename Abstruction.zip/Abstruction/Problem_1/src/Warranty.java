public interface Warranty
{

    void showWarranty () ;



}
