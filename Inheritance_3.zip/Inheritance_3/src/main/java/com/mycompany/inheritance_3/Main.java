/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_3;




import java.util.ArrayList  ;


import java.util.Scanner   ;





/**
 *
 * @author DELL
 */
public class Main 
{
    
    
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        ArrayList<Inheritance_3 > list = new ArrayList<>();

        // Fiction Book

        System.out.println("Enter Fiction Book Information");

        System.out.print("Title : ");
        String title = input.nextLine();

        System.out.print("Author : ");
        String author = input.nextLine();

        System.out.print("Price : ");
        int price = input.nextInt();

        input.nextLine();

        System.out.print("Genre : ");
        String genre = input.nextLine();

        list.add(new FictionBook(title, author, price, genre));

        // Non-Fiction Book

        System.out.println("\nEnter Non-Fiction Book Information");

        System.out.print("Title : ");
        title = input.nextLine();

        System.out.print("Author : ");
        author = input.nextLine();

        System.out.print("Price : ");
        price = input.nextInt();

        input.nextLine();

        System.out.print("Subject : ");
        String subject = input.nextLine();

        list.add(new NonFictionBook(title, author, price, subject));

        // Display

        System.out.println("\nBook Information");

        for (Inheritance_3  obj : list) 
        {

            obj.display();
            
            
            
            
             if (obj instanceof FictionBook book) 
            {
                book.action();
            }
             
             
             
             
            if (obj instanceof NonFictionBook book) 
            {
                book.action();
            }

            
            
            System.out.println(); 
            
        }
    }        
}       
    



