/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_3;

/**
 *
 * @author DELL
 */
public class NonFictionBook extends Inheritance_3  
{
    
    
    
    private String subject ; 

    
    
    
    
    
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
    
    
    
    
    
    public NonFictionBook (String title , String author , int price , String subject )
    {
        
        
        super(title, author, price)  ;
        this.subject = subject  ;
        
        
        
    }
    
    
    
    
    
    
    @Override
    public void display() 
    
    {

        super.display();
        System.out.println("Subject : " + subject)  ;

    }

    
    
    
    
    public void action() 
    {

        System.out.println("Action : Gain Knowledge") ;

    }
    
    
    
    
    
}
