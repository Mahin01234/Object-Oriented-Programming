/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_3;

/**
 *
 * @author DELL
 */
public class FictionBook extends Inheritance_3  
{
    
    private String genre ; 

    
    
    
    
    
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    
    
    
    
    public FictionBook (String title , String author , int price , String genre )  
    {
        
        super ( title , author , price ) ; 
        
        
        this.genre = genre ; 
        
    }
    
    
    
    
    
    
    @Override
    
    
    public void display () 
    {
        super.display() ; 
        
        System.out.println ("genre : " + genre ) ; 
        
        
        
    }
    
    
    

    
    
    public void action() 
    {

        System.out.println("Action : Enjoy Reading Fiction Book") ;

    }
    
    
    
    
}
