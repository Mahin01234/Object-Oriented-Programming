/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.book;

/**
 *
 * @author DELL
 */


// FictionBook.java
public class FictionBook extends Book 

{
    private String genre  ;

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public FictionBook(String title, String author, int price , String genre ) 
    {
        super(title, author, price) ;
        
        
        
        this.genre = genre ;
    }
    
    
   
    
    
    
    @Override
    
    public void display() 
    
    {
        
        super.display() ; 
        
        
        System.out.println("Genre: " + genre); 
        
        
    }
    
    
    

    public void recommend() 
    {
        System.out.println("If you like " + genre + "enjoy books") ;
    }

    
}
