/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.book;

/**
 *
 * @author DELL
 */
public class Book 
{    
    
    private String title , author  ; 
    private int price ; 

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    
    
    
    
    public Book(String title, String author, int price) {
        this.title = title;
        this.author = author;
        this.price = price;
    }
    
    
    
    
    public void display () 
    {
        
        System.out.println("Title is : " + title )  ; 
        
        System.out.println ("Author is : " + author ) ; 
        
        System.out.println ("Price : " + price ) ; 
        
        
        
        
    }
    
    
}
