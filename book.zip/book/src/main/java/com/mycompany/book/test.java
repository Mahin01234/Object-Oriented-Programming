/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.book;

/**
 *
 * @author DELL
 */


import java.util.ArrayList;

public class test 


{
    
    
    
    public static void main(String[] args) 
    
    
    
    {
        ArrayList<Book> books = new ArrayList<>();

        
        
        
        
        books.add(new FictionBook("Dune", "Frank Herbert", 1200 , "Science Fiction"));
        books.add(new NonFictionBook("Sapiens", "Yuval Noah Harari", 1850 , "History"));
        books.add(new FictionBook("The Hobbit", "J.R.R. Tolkien", 1075 , "Fantasy"));
        books.add(new NonFictionBook("The Selfish Gene", "Richard Dawkins", 1425 , "Science"));

       
        
        
        
        
        for (Book b : books) 
        
        {
            b.display();  

            
            
            
           
            if (b instanceof FictionBook fb) 
            
            
            {
                fb.recommend();
            } 
            
            
            
            else if (b instanceof NonFictionBook nfb) 
            {
                nfb.getSummary();
            }
            
            
            
            
         
            
        }
    }
}