/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shape;

/**
 *
 * @author DELL
 */
public class Circle extends Shape 
{
    
    private double raadius ; 

    public double getRaadius() {
        return raadius;
    }

    public void setRaadius(double raadius) {
        this.raadius = raadius;
    }

    
    
    
    public Circle(String name, String color, double raadius) {
        super(name, color);
        this.raadius = raadius;
    }

    
    @Override 
    public double getArea ()
    {
        return 3.1416 * raadius * raadius ; 
    }
    
    
    @Override
    public double getPerimeter() 
    {
        return 2 * 3.1416 * raadius ; 
    }
    
    
}
