/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shape;

/**
 *
 * @author DELL
 */

import java.util.ArrayList ;

public class main 


{
    public static void main(String[] args) 
    {
     
        ArrayList<Shape> shapeList = new ArrayList<>() ;

        
        shapeList.add(new Circle("Red Circle", "Red", 5.0)  ) ;
        shapeList.add(new Rectangle("Blue Rectangle", "Blue", 4.0, 6.0)) ;
        shapeList.add(new Circle("Small Green Circle", "Green", 2.5)) ;
        shapeList.add(new Rectangle("Yellow Square", "Yellow", 5.0, 5.0)) ;

        
        
        
        for (Shape s : shapeList) 
        
        {
            s.display() ;
            
        }
    }
}