/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.shape;

/**
 *
 * @author DELL
 */
public class Shape 
{
    

    private String name , color ; 

    
    
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    
    
    
    
    
    public Shape (String name , String color ) 
    {
        
        this.name = name ; 
        this.color = color ; 
        
    }
    
    
    
    
    
    
    
    
    public void display () 
    {
        
        System.out.println ("Name : " + name ) ; 
        
        System.out.println ("Color : " + color ) ; 
        
        
        
    }
    
}
