/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.shape;

/**
 *
 * @author DELL
 */



// Rectangle.java
public class Rectangle extends Shape 


{
    private double length;
    private double width;

   
    

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public Rectangle(String name, String color, double length, double width) {
        super(name, color);
        this.length = length;
        this.width = width;
    }

    
    
    
    
    
    public double getArea() 
    {
        return length * width;
    }

    
    
    
    
    public double getPerimeter() 
    {
        return 2 * (length + width);
    }
    
    
    
    
}
