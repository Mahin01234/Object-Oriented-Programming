/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inheritance_2;

/**
 *
 * @author DELL
 */
public class Inheritance_2
{
    
    
    private String name ; 
    private int Id ; 
    private double salary ; 

    
    
    
    
    
    
    
    
    
    
    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    
 
    
    
    
    
    
    public Inheritance_2 (String name , int Id , double salary )  
    {
        this.name = name ; 
        this.Id = Id ; 
        this.salary = salary ; 
        
    }
     
    
    
   
    
    
    
    
    
    
//    double calculateSalary() 
//    {
//        return salary;
//    }

    
    
    
    
    
    
    
    
    public void display() 
    {
        
        
        System.out.println ("Name : " + name ) ; 
        System.out.println ("ID : " + Id)  ;
        System.out.println ("Salary : " + salary )   ;
        
        
    }
    
    
    
    
    
    
}




