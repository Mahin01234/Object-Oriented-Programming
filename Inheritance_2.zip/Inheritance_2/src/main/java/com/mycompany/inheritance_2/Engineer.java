/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_2;

/**
 *
 * @author DELL
 */
public class Engineer extends Inheritance_2 
{
    
    
    private double Project_Bonus ; 

    
    
    
    
    
    
    
    
    
    public double getProject_Bonus() {
        return Project_Bonus;
    }

    public void setProject_Bonus(double Project_Bonus) {
        this.Project_Bonus = Project_Bonus;
    }
    
    
    
    
    
    
    
    
    public Engineer ( String name , int Id , double salary, double Project_Bonus ) 
    {
        
        
        super(name , Id , salary ) ;  
        
        this.Project_Bonus =  Project_Bonus  ; 
        
    }
    
    
    
    
    
    
    
    
    
    
    
    public double calculateSalary() 
    {
        
        return getSalary() + Project_Bonus  ;
    
    }
    
    
    
    
    
    
    
    @Override
    public void display () 
    {
        
        
        super.display() ; 
        
        
        System.out.println("Project_Bonus : " + Project_Bonus ) ; 
        System.out.println("Total Salary : " + calculateSalary() ) ; 
        
        
    }
       
    
    
    
    
    
}
