/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_2;




import java.util.ArrayList  ; 


import java.util.Scanner ; 




/**
 *
 * @author DELL
 */
public class Main 
{
    
    
    public static void main (String[] args ) 
    {
        
        
        
        Scanner input = new Scanner (System.in ) ; 
        
        
        ArrayList<Inheritance_2> C = new ArrayList<>() ; 
        
        
        
        
        System.out.println ("Enter the manager information - ") ; 

        System.out.print("Enter your name is : " ) ; 
        String name = input.nextLine() ; 
        
        System.out.print ("Enter your id is : " ) ; 
        int Id = input.nextInt () ; 
        
        System.out.print("Enter Salary : " ) ;
        double salary = input.nextDouble() ;

        System.out.print("Enter Bonus : " ) ; 
        double bonus = input.nextDouble() ;
        
        
        C.add (new Manager (name , Id , salary , bonus )) ; 
        
        input.nextLine() ; 
        
        
        
        
        
        
        
        
        System.out.println("\nEnter the Engineer Information" ) ;

        System.out.print("Enter your name is : " ) ;
        name = input.nextLine() ;

        System.out.print("Enter your iD is : " ) ;
        Id = input.nextInt() ;

        System.out.print("Enter Salary : " ) ;
        salary = input.nextDouble() ;

        System.out.print("Enter Project Bonus : " ) ;
        double Project_Bonus = input.nextDouble() ;

        C.add(new Engineer(name, Id, salary, Project_Bonus)) ;

        
        System.out.println("\nAll Information");

        for (Inheritance_2 obj : C ) 
        {

            obj.display() ;
            System.out.println() ; 

            
        }
        
    }
    
}
