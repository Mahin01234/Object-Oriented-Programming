/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_2;

/**
 *
 * @author DELL
 */
public class Manager extends Inheritance_2 
{
 
    
    private double bonus ; 

    
    
    
    
    
    
    
    
    
    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    
    
    
    
    
    
    
    
    public Manager (String name , int Id , double salary , double bonus )
    {
        
        super(name , Id , salary ) ; 
        
        
        
        this.bonus = bonus ; 
        
        
        
    }
    
    
    
    
    
    
    
    
    
    public double calculateSalary() 
    {
        
        return getSalary() + bonus ;
    
    }
    
    
    
    
    
    
    
    @Override
    public void display ()
    {
        
        super.display() ; 
    
        
        
        
       System.out.println("Bonus : " + bonus )  ; 
       System.out.println("Total Salary : " + calculateSalary() ) ;
       
    
    }  
    
    
    
    
}
