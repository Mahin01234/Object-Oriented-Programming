public abstract class User
{
    private String user_name;
    private String profile_picture;

    public User(String user_name, String profile_picture)
    {
        this.user_name = user_name;
        this.profile_picture = profile_picture;
    }

    public String getUser_name()
    {
        return user_name;
    }

    public void setUser_name(String user_name)
    {
        this.user_name = user_name;
    }

    public String getProfile_picture()
    {
        return profile_picture;
    }

    public void setProfile_picture(String profile_picture)
    {
        this.profile_picture = profile_picture;
    }

    public void display()
    {
        System.out.println("The user name is : " + user_name);
        System.out.println("The profile picture is : " + profile_picture);
    }

    public abstract void userType();
}



