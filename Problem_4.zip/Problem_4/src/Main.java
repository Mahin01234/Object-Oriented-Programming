import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);

        System.out.println(
                "========== REGULAR USER =========="
        );

        System.out.print("Enter User Name: ");
        String regular_name = input.nextLine();

        System.out.print("Enter Profile Picture: ");
        String regular_picture = input.nextLine();

        System.out.print("Enter Regular User Information: ");
        String regular_users = input.nextLine();

        Regular_User regular_user =
                new Regular_User(
                        regular_name,
                        regular_picture,
                        regular_users
                );


        System.out.println(
                "\n========== BUSINESS ACCOUNT =========="
        );

        System.out.print("Enter User Name: ");
        String business_user_name = input.nextLine();

        System.out.print("Enter Profile Picture: ");
        String business_picture = input.nextLine();

        System.out.print("Enter Business Name: ");
        String business_name = input.nextLine();

        BusinessAccount business_account =
                new BusinessAccount(
                        business_user_name,
                        business_picture,
                        business_name
                );


        System.out.println(
                "\n========== INFLUENCER =========="
        );

        System.out.print("Enter User Name: ");
        String influencer_name = input.nextLine();

        System.out.print("Enter Profile Picture: ");
        String influencer_picture = input.nextLine();

        System.out.print("Enter Followers: ");
        int followers = input.nextInt();


        Influencer influencer =
                new Influencer(
                        influencer_name,
                        influencer_picture,
                        followers
                );


        System.out.println(
                "\n========== OUTPUT =========="
        );


        System.out.println("\n--- REGULAR USER ---");

        regular_user.display();
        regular_user.userType();
        regular_user.post_content();
        regular_user.verifyAccount();


        System.out.println("\n--- BUSINESS ACCOUNT ---");

        business_account.display();
        business_account.userType();
        business_account.post_content();
        business_account.verifyAccount();


        System.out.println("\n--- INFLUENCER ---");

        influencer.display();
        influencer.userType();
        influencer.post_content();
        influencer.verifyAccount();


        input.close();
    }
}