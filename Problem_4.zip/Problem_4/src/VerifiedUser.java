public interface VerifiedUser
{
    void verifyAccount();
}


