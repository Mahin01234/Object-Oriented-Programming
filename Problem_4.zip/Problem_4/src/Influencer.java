public class Influencer
        extends User
        implements Post_Content, VerifiedUser
{
    private int followers;


    public int getFollowers() {
        return followers;
    }

    public void setFollowers(int followers) {
        this.followers = followers;
    }




    public Influencer(String user_name,
                      String profile_picture,
                      int followers)
    {
        super(user_name, profile_picture);

        this.followers = followers;
    }

    @Override
    public void userType()
    {
        System.out.println("User Type: Influencer");
    }

    @Override
    public void post_content()
    {
        System.out.println(
                "Influencer posted promotional content."
        );
    }

    @Override
    public void verifyAccount()
    {
        System.out.println("Influencer is Verified.");
    }

    @Override
    public void display()
    {
        super.display();

        System.out.println(
                "Followers: " + followers
        );
    }
}