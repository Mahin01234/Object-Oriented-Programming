public interface Post_Content
{
    void post_content();
}

