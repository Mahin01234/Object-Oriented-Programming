public class Regular_User
        extends User
        implements Post_Content, VerifiedUser
{
    private String regular_users;


    public String getRegular_users() {
        return regular_users;
    }

    public void setRegular_users(String regular_users) {
        this.regular_users = regular_users;
    }





    public Regular_User(String user_name, String profile_picture, String regular_users)

    {
        super(user_name, profile_picture);

        this.regular_users = regular_users;
    }

    @Override
    public void userType()
    {
        System.out.println("User Type: Regular User");
    }

    @Override
    public void post_content()
    {
        System.out.println("Regular user posted a new content.");
    }

    @Override
    public void verifyAccount()
    {
        System.out.println("Regular User is Verified.");
    }

    @Override
    public void display()
    {
        super.display();

        System.out.println(
                "The regular users are : " + regular_users
        );
    }
}