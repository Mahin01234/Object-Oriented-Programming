public class BusinessAccount
        extends User
        implements Post_Content, VerifiedUser
{
    private String business_name;


    public String getBusiness_name() {
        return business_name;
    }

    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }

    public BusinessAccount(String user_name, String profile_picture, String business_name)
    {
        super(user_name, profile_picture);

        this.business_name = business_name;
    }

    @Override
    public void userType()
    {
        System.out.println("User Type: Business Account");
    }

    @Override
    public void post_content()
    {
        System.out.println(
                "Business account posted advertisement content."
        );
    }

    @Override
    public void verifyAccount()
    {
        System.out.println("Business Account is Verified.");
    }

    @Override
    public void display()
    {
        super.display();

        System.out.println(
                "Business Name: " + business_name
        );
    }
}