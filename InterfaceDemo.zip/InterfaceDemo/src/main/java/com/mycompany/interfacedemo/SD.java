package com.mycompany.interfacedemo;

interface test {
    void sdSound(); // Interface method
    void sleep();   // Interface method
}

class Pig implements test {

    @Override
    public void sdSound() {
        System.out.println("The pig says: wee wee");
    }

    @Override
    public void sleep() {
        System.out.println("Zzz");
    }
}

public class SD {

    public static void main(String[] args) {

        Pig myPig = new Pig();

        myPig.sdSound();
        myPig.sleep();
    }
}