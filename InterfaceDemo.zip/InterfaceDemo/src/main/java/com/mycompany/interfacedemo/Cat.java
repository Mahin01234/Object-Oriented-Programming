/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.interfacedemo;

/**
 *
 * @author DELL
 */
public class Cat implements Animal
{
    
    public void eat() 
    {
        
        System.out.println ("Cat BD Lover.") ; 
        
        
    }
    
}
