/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.interfacedemo;

/**
 *
 * @author DELL
 */
public class InterfaceDemo {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
