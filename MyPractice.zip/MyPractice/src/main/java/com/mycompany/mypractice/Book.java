/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mypractice;

/**
 *
 * @author DELL
 */
// Book.java
public class Book extends Products implements Discountable, Returnable {
    private String author;
    private int pages;

    public Book(String name, double price, String author, int pages) {
        super(name, price);
        this.author = author;
        this.pages = pages;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    @Override
    public double calculateDiscount() {
      
        if (pages > 500) {
            return getPrice() * 0.20;
        } else if (pages > 300) {
            return getPrice() * 0.15;
        } else {
            return getPrice() * 0.10;
        }
    }

    @Override
    public boolean isReturnable() {
        return false;  
    }

    @Override
    public void displayInfo() {
        System.out.println("Book: " + getName() + ", Price: $" + getPrice() +
                           ", Author: " + author + ", Pages: " + pages);
    }
}