/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mypractice;

/**
 *
 * @author DELL
 */
public class MyPractice {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
