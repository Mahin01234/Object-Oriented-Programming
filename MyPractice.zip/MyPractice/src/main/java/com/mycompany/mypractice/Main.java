/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mypractice;

/**
 *
 * @author DELL
 */
// Main.java
// Main.java
public class Main {
    public static void main(String[] args) {
        // Electronics object
        Electronics laptop = new Electronics("Laptop", 1200.0, "Dell", 24);
        // Clothing object
        Clothing shirt = new Clothing("T-Shirt", 25.0, "M", "Cotton");
        // Book object
        Book novel = new Book("The Great Gatsby", 15.0, "F. Scott Fitzgerald", 180);

       
        Products[]  products = {laptop, shirt, novel};

        for (Products p : products) {
            p.displayInfo();
           
            if (p instanceof Discountable d) {
                double discount = d.calculateDiscount();
                System.out.println("  Discount: $" + String.format("%.2f", discount));
                System.out.println(String.format("%.2f", (p.getPrice() - discount)) + "  Price after discount: ");
            }
            
            if (p instanceof Returnable r) {
                System.out.println("  Returnable: " + (r.isReturnable() ? "Yes" : "No"));
            }
            System.out.println("---------------------------");
        }
    }
}