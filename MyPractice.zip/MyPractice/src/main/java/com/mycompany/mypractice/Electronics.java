/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mypractice;

/**
 *
 * @author DELL
 */
// Electronics.java
public class Electronics extends Products implements Discountable, Returnable 


{
    
    
    
    private String brand;
    private int warrantyMonths;

    public Electronics(String name, double price, String brand, int warrantyMonths) 
    {
        super(name, price);
        this.brand = brand;
        this.warrantyMonths = warrantyMonths;
    }

    Electronics(String laptop, double d, String dell, int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWarrantyMonths() {
        return warrantyMonths;
    }

    public void setWarrantyMonths(int warrantyMonths) 
    
    {
        this.warrantyMonths = warrantyMonths;
    }

    
    
    
    @Override
    public double calculateDiscount() 
    
    
    {
       
        if (warrantyMonths >= 24) {
            return getPrice() * 0.15;  
        } else if (warrantyMonths >= 12) {
            return getPrice() * 0.10;
        } else {
            return getPrice() * 0.05;
        }
    }
    
    
    
    
    
    
    
    @Override
    public void displayInfo() {
        System.out.println("Electronics: " + getName() + ", Price: $" + getPrice() +
                           ", Brand: " + brand + ", Warranty: " + warrantyMonths + " months");
    }
    
    
    

    @Override
    public boolean isReturnable() {
        return true;  
    }

    private double getPrice() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}
