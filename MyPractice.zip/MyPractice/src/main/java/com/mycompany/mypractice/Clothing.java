/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mypractice;

/**
 *
 * @author DELL
 */
// Clothing.java
public class Clothing extends Products implements Discountable 

{
    private String size;
    private String material;

    public Clothing(String name, double price, String size, String material) 
    
    {
        super(name, price);
        this.size = size;
        this.material = material;
    }

    Clothing(String tShirt, double d, String m, String cotton) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public double calculateDiscount() 
    
    {
        
        
        
        
        if (material.equalsIgnoreCase("cotton")) 
        {
            return getPrice() * 0.10;
        } 
        else if (material.equalsIgnoreCase("silk")) 
        {
            return getPrice() * 0.05;
        } 
        else 
        {
            return getPrice() * 0.02;
        }
        
        
        
    }

    @Override
    public void displayInfo() {
        System.out.println("Clothing: " + getName() + ", Price: $" + getPrice() +
                           ", Size: " + size + ", Material: " + material);
    }

    

    
    
    
    
    
}