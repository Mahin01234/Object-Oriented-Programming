/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_1;




import java.util.Scanner ; 


import java.util.ArrayList ; 









/**
 *
 * @author DELL
 */
public class Main 
{
    
    
    public static void main (String[] args ) 
    {
        
        
        
        Scanner input = new Scanner (System.in ) ; 
        
        
        ArrayList<Inheritance_1> a = new ArrayList<> () ; 
        
        
        
        
        
           
       
       
        System.out.println("Enter the car Information - ") ;

        
        
        
        // Car Input 
        System.out.print("Brand : ") ;
        String brand = input.nextLine() ;

        
        
        
        System.out.print("Model : ") ;
        String model = input.nextLine() ;

        
        
        
        
        System.out.print("Price : ") ;
        int price = input.nextInt() ;
        input.nextLine() ;

        
        
        
        
        System.out.print("Color : ") ;
        String color = input.nextLine() ;

        
        
        
        
        
        System.out.print("Door : ") ;
        int door = input.nextInt() ;
        input.nextLine() ;
        
        
        
        
        
        
        
        a.add(new Car(brand, model, color, price, door ) ) ;
        
        
        
        
        
        
        
        
        
        
        
        // Motorcycle Input
        System.out.println("\nEnter the Motorcycle Information")  ;

        
        
        
        System.out.print("Brand : ") ;
        brand = input.nextLine() ;

        
        
        
        System.out.print("Model : ") ;
        model = input.nextLine() ;

        
        
        
        System.out.print("Price : ") ;
        price = input.nextInt() ;
        input.nextLine() ; 

        
        
        
        
        
        System.out.print("Color : ") ;
        color = input.nextLine() ;

        
        
        
        
        
        System.out.print("Engine CC : ") ;
        int EngineCC = input.nextInt() ;

        
        
        
        
        a.add(new Motorcycle(brand, model, color, price, EngineCC))  ; 
        
        
        
        System.out.print("\n\n") ;
        System.out.print("ALL INFO : \n") ;
        
        
        
        
        for (Inheritance_1 v : a) 
        
        {
            v.display();
            
        
        }
        
        
        
        
        input.close();
        
        
        
    }
    
}
