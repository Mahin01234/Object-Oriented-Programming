/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inheritance_1;

/**
 *
 * @author DELL
 */
public class Motorcycle extends Inheritance_1 
{
    
    
    private int EngineCC ; 

    
    
    
    
    
    public int getEngineCC() {
        return EngineCC;
    }

    public void setEngineCC(int EngineCC) {
        this.EngineCC = EngineCC;
    }
    
    
    
    
    
    
    
    
    public Motorcycle (String  brand ,  String model , String color , int price, int EngineCC )
    {
        
        
        
        super(brand, model, color, price) ;  
        
        
        this.EngineCC = EngineCC ; 
    }
    
    
    
    
    
    
    
    
    
    @Override
        
    
    void display() 
    {
        super.display() ; 
        
        
        System.out.println("EngineCC : " + EngineCC)   ; 
        
        
        
        
    }
    
    
}




