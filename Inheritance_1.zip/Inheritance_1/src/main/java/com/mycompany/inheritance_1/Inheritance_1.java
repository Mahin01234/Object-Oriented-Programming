/*



 * Practice Problems - 

1. Create a class named "Vehicle" with properties such as "brand", "model", "price", and "color".
Create two subclasses, "Car" and "Motorcycle," with additional properties specific to each
class. Create a main class to initialize objects of the subclasses, store them in an ArrayList, and
display their information. Use the 'super' keyword to call the constructor of the superclass from
the subclasses and utilize method overriding. 



 */

package com.mycompany.inheritance_1;


public class Inheritance_1  // Vehicle == Inheritance 
{
    private String brand , model , color ; 
    private int price ; 

    
    
    
    
    
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    
    
    
   Inheritance_1 (String  brand ,  String model , String color , int price) 
   {
       
       
       this.brand = brand ; 
       this.model = model ; 
       this.color = color ; 
       this.price = price ; 
       
   }
    
    
   
   
   
   
   
   void display () 
   {
       System.out.println ("Brand : " + brand ); 
       System.out.println ("Model : " + model ); 
       System.out.println ("Color : " + color ); 
       System.out.println ("Price : " + price ); 
   } 
   
   
   
   
   
   
}
