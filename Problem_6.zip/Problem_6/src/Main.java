public class Main {

    public static void main(String[] args) {

        UndergraduateStudent student1 =
                new UndergraduateStudent(
                        "Mahin",
                        101,
                        2
                );

        GraduateStudent student2 =
                new GraduateStudent(
                        "Rahim",
                        102,
                        "Artificial Intelligence"
                );

        DoctoralStudent student3 =
                new DoctoralStudent(
                        "Karim",
                        103,
                        "Machine Learning"
                );


        System.out.println("----- Undergraduate Student -----");

        student1.showStudentType();

        System.out.println("Name: "
                + student1.getName());

        System.out.println("Student ID: "
                + student1.getStudentId());

        student1.enrollCourse();


        System.out.println("\n----- Graduate Student -----");

        student2.showStudentType();

        System.out.println("Name: "
                + student2.getName());

        System.out.println("Student ID: "
                + student2.getStudentId());

        student2.enrollCourse();
        student2.conductResearch();


        System.out.println("\n----- Doctoral Student -----");

        student3.showStudentType();

        System.out.println("Name: "
                + student3.getName());

        System.out.println("Student ID: "
                + student3.getStudentId());

        student3.enrollCourse();
        student3.conductResearch();
    }
}


