public interface Researchable {

    void conductResearch();
}


