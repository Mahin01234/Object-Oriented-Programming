public class UndergraduateStudent extends Student
        implements CourseEnrollment {

    private int year;


    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public UndergraduateStudent(String name, int studentId, int year) {
        super(name, studentId);
        this.year = year;
    }

    @Override
    public void showStudentType() {
        System.out.println("Student Type: Undergraduate Student");
    }

    @Override
    public void enrollCourse() {
        System.out.println(getName() + " enrolled in an undergraduate course.");
    }
}



