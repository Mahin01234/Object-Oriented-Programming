public interface CourseEnrollment {

    void enrollCourse();
}



