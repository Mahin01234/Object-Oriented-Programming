public class GraduateStudent extends Student
        implements CourseEnrollment, Researchable {

    private String thesisTopic;

    public String getThesisTopic() {
        return thesisTopic;
    }

    public void setThesisTopic(String thesisTopic) {
        this.thesisTopic = thesisTopic;
    }

    public GraduateStudent(String name, int studentId, String thesisTopic) {
        super(name, studentId);
        this.thesisTopic = thesisTopic;
    }

    @Override
    public void showStudentType() {
        System.out.println("Student Type: Graduate Student");
    }

    @Override
    public void enrollCourse() {
        System.out.println(getName() + " enrolled in a graduate course.");
    }

    @Override
    public void conductResearch() {
        System.out.println(getName()
                + " is conducting research on "
                + thesisTopic);
    }
}



