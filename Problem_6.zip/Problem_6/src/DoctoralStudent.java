public class DoctoralStudent extends Student
        implements CourseEnrollment, Researchable {

    private String researchArea;


    public String getResearchArea() {
        return researchArea;
    }

    public void setResearchArea(String researchArea) {
        this.researchArea = researchArea;
    }

    public DoctoralStudent(String name, int studentId,
                           String researchArea) {

        super(name, studentId);
        this.researchArea = researchArea;
    }

    @Override
    public void showStudentType() {
        System.out.println("Student Type: Doctoral Student");
    }

    @Override
    public void enrollCourse() {
        System.out.println(getName()
                + " enrolled in a doctoral course.");
    }

    @Override
    public void conductResearch() {
        System.out.println(getName()
                + " is conducting doctoral research on "
                + researchArea);
    }
}


